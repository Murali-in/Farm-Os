import { useState } from "react";
import Header from "@/components/Header";
import SystemStatusCard from "@/components/SystemStatusCard";
import SensorCards from "@/components/SensorCards";
import WeatherAdvisory from "@/components/WeatherAdvisory";
import MobileMenu from "@/components/MobileMenu";

const Index = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <Header onMenuOpen={() => setMenuOpen(true)} />
      <MobileMenu isOpen={menuOpen} onClose={() => setMenuOpen(false)} />

      <main className="px-4 py-6 space-y-6 md:px-8 lg:px-12 max-w-7xl mx-auto">
        {/* Dashboard Title */}
        <div>
          <h1 className="text-2xl font-bold text-foreground mb-1 md:text-3xl">Dashboard</h1>
          <p className="text-muted-foreground md:text-lg">Real-time overview of your farm operations</p>
        </div>

        {/* Responsive grid for tablet/desktop */}
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Left column - System Status + Sensor Cards */}
          <div className="lg:col-span-2 space-y-6">
            {/* System Status */}
            <SystemStatusCard />

            {/* Sensor Cards Grid */}
            <SensorCards />
          </div>

          {/* Right column - Weather Advisory */}
          <div className="lg:col-span-1">
            <WeatherAdvisory />
          </div>
        </div>
      </main>
    </div>
  );
};

export default Index;
