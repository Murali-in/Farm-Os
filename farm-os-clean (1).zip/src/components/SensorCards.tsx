import { Thermometer, Droplets, Sprout, Wind, LucideIcon } from "lucide-react";

interface SensorCardProps {
  icon: LucideIcon;
  title: string;
  value: string;
  unit: string;
  status: "online" | "offline";
}

const SensorCard = ({ icon: Icon, title, value, unit, status }: SensorCardProps) => {
  return (
    <div className="sensor-card">
      {/* Top row - Icon and status */}
      <div className="flex items-start justify-between mb-4">
        <div className="icon-container">
          <Icon className="w-6 h-6" />
        </div>
        <div className="flex items-center gap-1.5">
          <span className={status === "online" ? "status-dot-online" : "status-dot-offline"} />
          <span className="text-sm text-muted-foreground capitalize">{status}</span>
        </div>
      </div>

      {/* Title */}
      <h3 className="text-base font-semibold text-primary mb-2">{title}</h3>

      {/* Value */}
      <div className="flex items-baseline gap-1 mb-1">
        {value === "—" ? (
          <span className="value-dash" />
        ) : (
          <span className="text-2xl font-semibold text-foreground">{value}</span>
        )}
        <span className="text-lg text-muted-foreground">{unit}</span>
      </div>

      {/* Status text */}
      <p className="text-sm text-muted-foreground">No data</p>
    </div>
  );
};

const SensorCards = () => {
  const sensors: SensorCardProps[] = [
    {
      icon: Thermometer,
      title: "Temperature",
      value: "—",
      unit: "°C",
      status: "offline",
    },
    {
      icon: Droplets,
      title: "Soil Moisture",
      value: "—",
      unit: "%",
      status: "offline",
    },
    {
      icon: Sprout,
      title: "Grass Growth",
      value: "—",
      unit: "%",
      status: "offline",
    },
    {
      icon: Wind,
      title: "Wind Speed",
      value: "—",
      unit: "km/h",
      status: "offline",
    },
  ];

  return (
    <div className="grid grid-cols-2 gap-4 md:grid-cols-4 lg:grid-cols-2">
      {sensors.map((sensor) => (
        <SensorCard key={sensor.title} {...sensor} />
      ))}
    </div>
  );
};

export default SensorCards;
