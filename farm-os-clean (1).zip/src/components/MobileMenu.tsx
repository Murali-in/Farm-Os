import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import FieldsTab from "./tabs/FieldsTab";
import FieldHistoryTab from "./tabs/FieldHistoryTab";
import WeatherTab from "./tabs/WeatherTab";

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

const MobileMenu = ({ isOpen, onClose }: MobileMenuProps) => {
  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="right" className="w-full sm:w-[400px] md:w-[500px] lg:w-[600px] p-0 overflow-y-auto">
        <SheetHeader className="px-4 py-4 border-b border-border">
          <div className="flex items-center justify-between">
            <SheetTitle className="text-lg font-semibold text-foreground">Menu</SheetTitle>
          </div>
        </SheetHeader>
        
        <Tabs defaultValue="fields" className="w-full">
          <TabsList className="w-full grid grid-cols-3 h-auto p-1 bg-secondary/50 rounded-none">
            <TabsTrigger 
              value="fields" 
              className="text-xs sm:text-sm py-2 data-[state=active]:bg-card data-[state=active]:text-primary"
            >
              Fields
            </TabsTrigger>
            <TabsTrigger 
              value="history" 
              className="text-xs sm:text-sm py-2 data-[state=active]:bg-card data-[state=active]:text-primary"
            >
              History
            </TabsTrigger>
            <TabsTrigger 
              value="weather" 
              className="text-xs sm:text-sm py-2 data-[state=active]:bg-card data-[state=active]:text-primary"
            >
              Weather
            </TabsTrigger>
          </TabsList>

          <div className="p-4">
            <TabsContent value="fields" className="mt-0">
              <FieldsTab />
            </TabsContent>
            <TabsContent value="history" className="mt-0">
              <FieldHistoryTab />
            </TabsContent>
            <TabsContent value="weather" className="mt-0">
              <WeatherTab />
            </TabsContent>
          </div>
        </Tabs>
      </SheetContent>
    </Sheet>
  );
};

export default MobileMenu;
