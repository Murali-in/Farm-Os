import { useState, useEffect } from "react";
import { 
  Circle, 
  Droplets, 
  CloudRain, 
  AlertTriangle, 
  Sprout,
  CheckCircle2
} from "lucide-react";

interface HistoryEvent {
  id: string;
  type: "created" | "irrigation" | "weather_alert" | "harvest" | "planted";
  fieldName: string;
  description: string;
  date: Date;
}

const generateDemoHistory = (): HistoryEvent[] => {
  const now = new Date();
  return [
    {
      id: "1",
      type: "created",
      fieldName: "North Acre",
      description: "Field was registered in the system",
      date: new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000),
    },
    {
      id: "2",
      type: "planted",
      fieldName: "North Acre",
      description: "Wheat crop planted successfully",
      date: new Date(now.getTime() - 6 * 24 * 60 * 60 * 1000),
    },
    {
      id: "3",
      type: "irrigation",
      fieldName: "North Acre",
      description: "Automated irrigation completed - 500 gallons",
      date: new Date(now.getTime() - 4 * 24 * 60 * 60 * 1000),
    },
    {
      id: "4",
      type: "weather_alert",
      fieldName: "South Field",
      description: "Heavy rain warning issued for the area",
      date: new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000),
    },
    {
      id: "5",
      type: "irrigation",
      fieldName: "East Plot",
      description: "Irrigation paused due to weather conditions",
      date: new Date(now.getTime() - 1 * 24 * 60 * 60 * 1000),
    },
    {
      id: "6",
      type: "harvest",
      fieldName: "West Garden",
      description: "Vegetable harvest completed successfully",
      date: new Date(now.getTime() - 12 * 60 * 60 * 1000),
    },
  ];
};

const getEventIcon = (type: HistoryEvent["type"]) => {
  switch (type) {
    case "created":
      return <Circle className="w-4 h-4" />;
    case "irrigation":
      return <Droplets className="w-4 h-4" />;
    case "weather_alert":
      return <CloudRain className="w-4 h-4" />;
    case "harvest":
      return <CheckCircle2 className="w-4 h-4" />;
    case "planted":
      return <Sprout className="w-4 h-4" />;
    default:
      return <Circle className="w-4 h-4" />;
  }
};

const getEventColor = (type: HistoryEvent["type"]) => {
  switch (type) {
    case "created":
      return "bg-secondary text-primary";
    case "irrigation":
      return "bg-blue-100 text-blue-600";
    case "weather_alert":
      return "bg-amber-100 text-amber-600";
    case "harvest":
      return "bg-green-100 text-green-600";
    case "planted":
      return "bg-emerald-100 text-emerald-600";
    default:
      return "bg-secondary text-primary";
  }
};

const formatDate = (date: Date) => {
  const now = new Date();
  const diff = now.getTime() - new Date(date).getTime();
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor(diff / (1000 * 60 * 60));
  
  if (hours < 24) {
    return `${hours} hours ago`;
  } else if (days === 1) {
    return "Yesterday";
  } else if (days < 7) {
    return `${days} days ago`;
  } else {
    return new Date(date).toLocaleDateString();
  }
};

const FieldHistoryTab = () => {
  const [history] = useState<HistoryEvent[]>(generateDemoHistory());

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-foreground">Field Activity Timeline</h3>
      
      <div className="relative">
        {/* Timeline line */}
        <div className="absolute left-5 top-0 bottom-0 w-0.5 bg-border" />
        
        {/* Timeline events */}
        <div className="space-y-4">
          {history.map((event, index) => (
            <div key={event.id} className="relative flex items-start gap-4 pl-2">
              {/* Timeline dot */}
              <div className={`relative z-10 flex items-center justify-center w-8 h-8 rounded-full ${getEventColor(event.type)}`}>
                {getEventIcon(event.type)}
              </div>
              
              {/* Event content */}
              <div className="flex-1 p-3 rounded-xl border border-border bg-card -mt-1">
                <div className="flex items-start justify-between gap-2 mb-1">
                  <h4 className="font-medium text-foreground text-sm">{event.fieldName}</h4>
                  <span className="text-xs text-muted-foreground whitespace-nowrap">
                    {formatDate(event.date)}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">{event.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FieldHistoryTab;
