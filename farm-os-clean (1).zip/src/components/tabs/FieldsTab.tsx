import { useState, useEffect } from "react";
import { Plus, Trash2, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface Field {
  id: string;
  name: string;
  size: number;
  createdAt: Date;
}

const FieldsTab = () => {
  const [fields, setFields] = useState<Field[]>([]);
  const [fieldName, setFieldName] = useState("");
  const [fieldSize, setFieldSize] = useState("");
  const [showForm, setShowForm] = useState(false);

  // Load fields from localStorage on mount
  useEffect(() => {
    const savedFields = localStorage.getItem("farmOS-fields");
    if (savedFields) {
      setFields(JSON.parse(savedFields));
    }
  }, []);

  // Save fields to localStorage when changed
  useEffect(() => {
    localStorage.setItem("farmOS-fields", JSON.stringify(fields));
  }, [fields]);

  const handleAddField = () => {
    if (!fieldName.trim() || !fieldSize.trim()) return;
    
    const newField: Field = {
      id: Date.now().toString(),
      name: fieldName.trim(),
      size: parseFloat(fieldSize),
      createdAt: new Date(),
    };
    
    setFields([...fields, newField]);
    setFieldName("");
    setFieldSize("");
    setShowForm(false);
  };

  const handleDeleteField = (id: string) => {
    setFields(fields.filter(f => f.id !== id));
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-foreground">My Fields</h3>
        <Button 
          size="sm" 
          onClick={() => setShowForm(!showForm)}
          className="bg-primary text-primary-foreground hover:bg-primary/90"
        >
          <Plus className="w-4 h-4 mr-1" />
          Add Field
        </Button>
      </div>

      {showForm && (
        <div className="p-4 rounded-xl border border-border bg-card space-y-4">
          <div className="space-y-2">
            <Label htmlFor="fieldName">Field Name</Label>
            <Input
              id="fieldName"
              placeholder="e.g., North Acre"
              value={fieldName}
              onChange={(e) => setFieldName(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="fieldSize">Field Size (acres)</Label>
            <Input
              id="fieldSize"
              type="number"
              placeholder="e.g., 5"
              value={fieldSize}
              onChange={(e) => setFieldSize(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
            <Button onClick={handleAddField} className="bg-primary text-primary-foreground">
              Save Field
            </Button>
            <Button variant="outline" onClick={() => setShowForm(false)}>
              Cancel
            </Button>
          </div>
        </div>
      )}

      {fields.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">
          <MapPin className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>No fields added yet.</p>
          <p className="text-sm">Tap "Add Field" to create your first field.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {fields.map((field) => (
            <div 
              key={field.id} 
              className="p-4 rounded-xl border border-border bg-card flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <div className="icon-container">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-medium text-foreground">{field.name}</h4>
                  <p className="text-sm text-muted-foreground">{field.size} acres</p>
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => handleDeleteField(field.id)}
                className="text-destructive hover:bg-destructive/10"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default FieldsTab;
