import { useState, useEffect } from "react";
import { Cloud, Bot, MapPin, Loader2, Thermometer, Droplets, Wind } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";

interface WeatherData {
  temperature: number;
  humidity: number;
  windSpeed: number;
  description: string;
  condition: string;
}

const INDIAN_STATES = [
  "Andhra Pradesh",
  "Arunachal Pradesh", 
  "Assam",
  "Bihar",
  "Chhattisgarh",
  "Goa",
  "Gujarat",
  "Haryana",
  "Himachal Pradesh",
  "Jharkhand",
  "Karnataka",
  "Kerala",
  "Madhya Pradesh",
  "Maharashtra",
  "Manipur",
  "Meghalaya",
  "Mizoram",
  "Nagaland",
  "Odisha",
  "Punjab",
  "Rajasthan",
  "Sikkim",
  "Tamil Nadu",
  "Telangana",
  "Tripura",
  "Uttar Pradesh",
  "Uttarakhand",
  "West Bengal",
];

// State capitals for weather lookup
const STATE_CAPITALS: Record<string, string> = {
  "Andhra Pradesh": "Amaravati",
  "Arunachal Pradesh": "Itanagar",
  "Assam": "Dispur",
  "Bihar": "Patna",
  "Chhattisgarh": "Raipur",
  "Goa": "Panaji",
  "Gujarat": "Gandhinagar",
  "Haryana": "Chandigarh",
  "Himachal Pradesh": "Shimla",
  "Jharkhand": "Ranchi",
  "Karnataka": "Bengaluru",
  "Kerala": "Thiruvananthapuram",
  "Madhya Pradesh": "Bhopal",
  "Maharashtra": "Mumbai",
  "Manipur": "Imphal",
  "Meghalaya": "Shillong",
  "Mizoram": "Aizawl",
  "Nagaland": "Kohima",
  "Odisha": "Bhubaneswar",
  "Punjab": "Chandigarh",
  "Rajasthan": "Jaipur",
  "Sikkim": "Gangtok",
  "Tamil Nadu": "Chennai",
  "Telangana": "Hyderabad",
  "Tripura": "Agartala",
  "Uttar Pradesh": "Lucknow",
  "Uttarakhand": "Dehradun",
  "West Bengal": "Kolkata",
};

const generateAdvisory = (weather: WeatherData | null, state: string): string[] => {
  if (!weather) return [];
  
  const advisories: string[] = [];
  
  if (weather.temperature > 35) {
    advisories.push("Avoid fieldwork during peak afternoon hours due to extreme heat.");
    advisories.push("Ensure adequate hydration for workers and livestock.");
  } else if (weather.temperature > 30) {
    advisories.push("Warm conditions expected. Consider early morning irrigation.");
  } else if (weather.temperature < 15) {
    advisories.push("Cool temperatures may slow crop growth. Monitor soil moisture carefully.");
  }
  
  if (weather.humidity > 80) {
    advisories.push("High humidity may increase risk of fungal diseases. Inspect crops closely.");
  }
  
  if (weather.windSpeed > 20) {
    advisories.push("Strong winds expected. Secure any loose equipment and structures.");
  }
  
  if (weather.condition.toLowerCase().includes("rain")) {
    advisories.push("Rainfall expected. Postpone pesticide or fertilizer application.");
  }
  
  if (advisories.length === 0) {
    advisories.push("Weather conditions are favorable for normal field operations.");
    advisories.push("Good day for planting or harvesting activities.");
  }
  
  return advisories;
};

const WeatherTab = () => {
  const [selectedState, setSelectedState] = useState<string>("");
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!selectedState) return;
    
    const fetchWeather = async () => {
      setLoading(true);
      setError(null);
      
      try {
        const city = STATE_CAPITALS[selectedState];
        // Using Open-Meteo API (free, no API key required)
        const geoResponse = await fetch(
          `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=en&format=json`
        );
        const geoData = await geoResponse.json();
        
        if (!geoData.results || geoData.results.length === 0) {
          throw new Error("Location not found");
        }
        
        const { latitude, longitude } = geoData.results[0];
        
        const weatherResponse = await fetch(
          `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code`
        );
        const weatherData = await weatherResponse.json();
        
        const weatherCodes: Record<number, string> = {
          0: "Clear sky",
          1: "Mainly clear",
          2: "Partly cloudy",
          3: "Overcast",
          45: "Foggy",
          48: "Depositing rime fog",
          51: "Light drizzle",
          53: "Moderate drizzle",
          55: "Dense drizzle",
          61: "Slight rain",
          63: "Moderate rain",
          65: "Heavy rain",
          71: "Slight snow",
          73: "Moderate snow",
          75: "Heavy snow",
          80: "Slight rain showers",
          81: "Moderate rain showers",
          82: "Violent rain showers",
          95: "Thunderstorm",
        };
        
        setWeather({
          temperature: Math.round(weatherData.current.temperature_2m),
          humidity: weatherData.current.relative_humidity_2m,
          windSpeed: Math.round(weatherData.current.wind_speed_10m),
          description: weatherCodes[weatherData.current.weather_code] || "Unknown",
          condition: weatherCodes[weatherData.current.weather_code] || "Unknown",
        });
      } catch (err) {
        setError("Unable to fetch weather data. Please try again.");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchWeather();
  }, [selectedState]);

  const advisories = generateAdvisory(weather, selectedState);

  return (
    <div className="space-y-5">
      <div className="space-y-2">
        <Label htmlFor="state" className="text-sm font-medium">Select Your State</Label>
        <Select value={selectedState} onValueChange={setSelectedState}>
          <SelectTrigger id="state" className="w-full">
            <SelectValue placeholder="Choose a state..." />
          </SelectTrigger>
          <SelectContent className="max-h-[300px]">
            {INDIAN_STATES.map((state) => (
              <SelectItem key={state} value={state}>
                {state}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {loading && (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      )}

      {error && (
        <div className="p-4 rounded-xl border border-destructive/50 bg-destructive/10 text-destructive text-sm">
          {error}
        </div>
      )}

      {weather && !loading && (
        <>
          {/* Weather Data Card */}
          <div className="p-4 rounded-xl border border-border bg-card">
            <div className="flex items-center gap-2 mb-4">
              <MapPin className="w-4 h-4 text-primary" />
              <span className="font-medium text-foreground">{selectedState}</span>
            </div>
            
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <Thermometer className="w-6 h-6 mx-auto mb-1 text-primary" />
                <div className="text-xl font-semibold text-foreground">{weather.temperature}°C</div>
                <div className="text-xs text-muted-foreground">Temperature</div>
              </div>
              <div className="text-center">
                <Droplets className="w-6 h-6 mx-auto mb-1 text-primary" />
                <div className="text-xl font-semibold text-foreground">{weather.humidity}%</div>
                <div className="text-xs text-muted-foreground">Humidity</div>
              </div>
              <div className="text-center">
                <Wind className="w-6 h-6 mx-auto mb-1 text-primary" />
                <div className="text-xl font-semibold text-foreground">{weather.windSpeed}</div>
                <div className="text-xs text-muted-foreground">km/h Wind</div>
              </div>
            </div>
            
            <div className="mt-4 pt-4 border-t border-border">
              <div className="flex items-center gap-2">
                <Cloud className="w-5 h-5 text-primary" />
                <span className="text-sm text-muted-foreground">{weather.description}</span>
              </div>
            </div>
          </div>

          {/* Weather Prediction */}
          <div className="p-4 rounded-xl border border-border bg-card">
            <div className="flex items-center gap-3 mb-3">
              <div className="icon-container w-10 h-10">
                <Cloud className="w-5 h-5" />
              </div>
              <h3 className="text-base font-semibold text-primary">Weather Prediction</h3>
            </div>
            <p className="text-sm text-muted-foreground">
              {weather.temperature > 35 
                ? `High temperature of ${weather.temperature}°C expected today in ${selectedState}.`
                : weather.temperature < 15
                ? `Cool conditions with ${weather.temperature}°C expected in ${selectedState}.`
                : `Moderate temperature of ${weather.temperature}°C in ${selectedState}. ${weather.description}.`
              }
            </p>
          </div>

          {/* Robot Advisory */}
          <div className="p-4 rounded-xl border border-border bg-card">
            <div className="flex items-center gap-3 mb-3">
              <div className="icon-container w-10 h-10">
                <Bot className="w-5 h-5" />
              </div>
              <h3 className="text-base font-semibold text-primary">Robot Advisory</h3>
            </div>
            <ul className="space-y-2">
              {advisories.map((advisory, index) => (
                <li key={index} className="text-sm text-muted-foreground italic">
                  "{advisory}"
                </li>
              ))}
            </ul>
          </div>
        </>
      )}

      {!selectedState && !loading && (
        <div className="text-center py-8 text-muted-foreground">
          <Cloud className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>Select a state to view weather data</p>
          <p className="text-sm">Real-time weather and farming advisories</p>
        </div>
      )}
    </div>
  );
};

export default WeatherTab;
