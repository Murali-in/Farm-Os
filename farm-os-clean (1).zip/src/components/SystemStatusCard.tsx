import { Wifi, Database, Server, Clock } from "lucide-react";

const SystemStatusCard = () => {
  return (
    <div className="system-status-card">
      {/* Top row - System, Robot, Data points */}
      <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
        {/* System Online */}
        <div className="flex items-center gap-2">
          <span className="status-dot-online" />
          <div>
            <div className="text-sm font-medium text-status-card-foreground">System</div>
            <div className="text-sm text-muted-foreground">Online</div>
          </div>
        </div>

        {/* Robot Connected */}
        <div className="flex items-center gap-2">
          <Wifi className="w-5 h-5 text-primary" />
          <div>
            <div className="text-sm font-medium text-status-card-foreground">Robot</div>
            <div className="text-sm text-muted-foreground">Connected</div>
          </div>
        </div>

        {/* Data points */}
        <div className="flex items-center gap-2">
          <Database className="w-5 h-5 text-primary" />
          <div>
            <div className="text-sm font-medium text-status-card-foreground">0 data</div>
            <div className="text-sm text-muted-foreground">points</div>
          </div>
        </div>
      </div>

      {/* Bottom row - Uptime, Last sync */}
      <div className="flex flex-wrap items-center gap-4 md:gap-8">
        {/* Uptime */}
        <div className="flex items-center gap-2">
          <Server className="w-5 h-5 text-primary" />
          <span className="text-sm text-muted-foreground">Uptime: —</span>
        </div>

        {/* Last sync */}
        <div className="flex items-center gap-2">
          <Clock className="w-5 h-5 text-primary" />
          <span className="text-sm text-muted-foreground">Last sync: No data</span>
        </div>
      </div>
    </div>
  );
};

export default SystemStatusCard;
