import { Menu, Sprout, X } from "lucide-react";
import { useState } from "react";
import MobileMenu from "./MobileMenu";

interface HeaderProps {
  onMenuOpen: () => void;
}

const Header = ({ onMenuOpen }: HeaderProps) => {
  return (
    <header className="flex items-center justify-between px-4 py-4 border-b border-border md:px-8 lg:px-12">
      {/* Logo */}
      <div className="flex items-center gap-3">
        <div className="icon-container">
          <Sprout className="w-6 h-6" />
        </div>
        <span className="text-xl font-semibold text-foreground">Farm OS</span>
      </div>

      {/* Right - Hamburger menu only */}
      <button 
        className="p-2 text-foreground hover:bg-secondary rounded-lg transition-colors" 
        aria-label="Menu"
        onClick={onMenuOpen}
      >
        <Menu className="w-6 h-6" />
      </button>
    </header>
  );
};

export default Header;
