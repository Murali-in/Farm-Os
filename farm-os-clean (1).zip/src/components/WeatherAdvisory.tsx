import { Cloud, Bot } from "lucide-react";

const WeatherAdvisory = () => {
  return (
    <div className="space-y-4">
      {/* Weather Prediction */}
      <div className="sensor-card">
        <div className="flex items-center gap-3 mb-3">
          <div className="icon-container">
            <Cloud className="w-6 h-6" />
          </div>
          <h3 className="text-base font-semibold text-primary">Weather Prediction</h3>
        </div>
        <ul className="space-y-2 text-sm text-muted-foreground">
          <li>• High heat expected today</li>
          <li>• Possible rain later in the evening</li>
        </ul>
      </div>

      {/* Robot Advisory */}
      <div className="sensor-card">
        <div className="flex items-center gap-3 mb-3">
          <div className="icon-container">
            <Bot className="w-6 h-6" />
          </div>
          <h3 className="text-base font-semibold text-primary">Robot Advisory</h3>
        </div>
        <ul className="space-y-2 text-sm text-muted-foreground italic">
          <li>"Avoid irrigation during afternoon hours."</li>
          <li>"Field conditions are stable for operations."</li>
        </ul>
      </div>
    </div>
  );
};

export default WeatherAdvisory;
