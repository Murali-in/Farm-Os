# Farm OS - Installation Guide

## Quick Start

1. **Extract the zip file**
   ```bash
   unzip farm-os-clean.zip
   cd farm-os
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Run the development server**
   ```bash
   npm run dev
   ```

4. **Open your browser**
   Navigate to `http://localhost:8080`

## Next Steps

After installation, you may want to:
- Update the project name in `package.json` if needed
- Configure your own Git repository
- Customize the branding and colors
- Add your own deployment configuration

## Support

For issues or questions about the code, please refer to the README.md file included in the project.
